class NoxUIAutomator:
    def __init__(self):
        pass

    def getCurrentUIHierarchy(self, pretty=False):
        pass
