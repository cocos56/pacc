"""PACC模块"""


def get_version():
    """获取当前PACC的版本号"""
    version = '0.0.569'
    print(f'Your PACC version is {version}')
    return version
