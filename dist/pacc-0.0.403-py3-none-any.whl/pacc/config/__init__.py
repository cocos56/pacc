"""配置包的初始化模块"""
from .config import Config, Language

__all__ = [
    'Config',
    'Language',
]
