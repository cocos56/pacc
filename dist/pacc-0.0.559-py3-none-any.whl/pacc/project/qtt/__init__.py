"""趣头条中央控制系统包的初始化模块"""
from .qtt import Qtt

__all__ = [
    'Qtt',
]
