"""快手极速版工程包的初始化模块"""
from .ksjsb import KSJSB

__all__ = [
    'KSJSB'
]
