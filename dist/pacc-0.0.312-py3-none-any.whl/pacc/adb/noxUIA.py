class NoxUIAutomator:
    def __init__(self, noxIndex):
        self.noxIndex = noxIndex

    def getCurrentUIHierarchy(self, pretty=False):
        pass
