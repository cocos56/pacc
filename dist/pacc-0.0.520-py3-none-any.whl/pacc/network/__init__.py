"""网络包的初始化模块"""
from .ucc_server import UCCServer

__all__ = [
    'UCCServer',
]
