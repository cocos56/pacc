from ...base import run_forever
from .ksjsb import Ksjsb


class KsjsbMainloop:

    @classmethod
    @run_forever
    def run(cls):
        print(1)
        pass

