"""快手极速版工程包的边界值（位于目标矩形的斜对角的两点坐标）模块"""


# pylint: disable=too-few-public-methods
class Bounds:
    """快手极速版边界值类"""
    close_congratulations = '[78,405][174,501]'  # 关闭恭喜获得好友看视频奖励
