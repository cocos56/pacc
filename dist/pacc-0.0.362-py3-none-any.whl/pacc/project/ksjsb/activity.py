root = 'com.kuaishou.nebula/com.'

AwardFeedFlowActivity = root + 'yxcorp.gifshow.ad.award.flow.AwardFeedFlowActivity'
HomeActivity = root + 'yxcorp.gifshow.HomeActivity'  # 主界面
PhotoDetailActivity = root + 'yxcorp.gifshow.detail.PhotoDetailActivity'  # 直播
UserProfileActivity = root + 'yxcorp.gifshow.profile.activity.UserProfileActivity'  # 用户主页
AdYodaActivity = root + 'yxcorp.gifshow.ad.webview.AdYodaActivity'  # 广告（看视频时出现）
AwardVideoPlayActivity = root + 'yxcorp.gifshow.ad.award.AwardVideoPlayActivity'  # 看广告界面（由财富界面转入）
KwaiYodaWebViewActivity = root + 'yxcorp.gifshow.webview.KwaiYodaWebViewActivity'  # 财富界面
TopicDetailActivity = root + 'yxcorp.plugin.tag.topic.TopicDetailActivity'  # 每日书单
MiniAppActivity0 = root + 'mini.app.activity.MiniAppActivity0'  # 小程序
KRT1Activity = root + 'kwai.frog.game.engine.adapter.engine.base.KRT1Activity'  # 拯救小金鱼游戏
SearchActivity = 'com.android.quicksearchbox/com.android.quicksearchbox.SearchActivity'

