import os


class NoxProj:

    def __init__(self, noxWorkPath=r'D:\Program Files\Nox\bin'):
        os.chdir(noxWorkPath)
