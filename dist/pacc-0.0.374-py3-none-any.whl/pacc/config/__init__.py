"""配置包的初始化模块"""
from .config import Config

__all__ = [
    'Config',
]
